package com.reign.ast.sdk.alipay;

/**
 * alix id
 * @author zhouwenjia
 *
 */
public final class AlixId {
	public static final int BASE_ID = 0;  
    public static final int RQF_PAY = BASE_ID + 1;  
    public static final int RQF_INSTALL_CHECK = RQF_PAY + 1; 
}
